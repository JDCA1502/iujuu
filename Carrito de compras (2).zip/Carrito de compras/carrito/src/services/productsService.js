import { product } from "../data/products";

export const getProducts = () => {
    return product;
};

export const calcularTotal = (items) => {
    return items.reduce(
        (accumulator,item) => accumulator+item.product.precio * item.quantity, 0
    );
};