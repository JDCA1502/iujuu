import imagen_antifluido from "../assets/img/imagen_antifluido.png";
import imagen_dacron from "../assets/img/imagen_dacron.png";
import imagen_doble_punto from "../assets/img/imagen_doble_punto.png";
import imagen_pacific from "../assets/img/imagen_pacific.png";
import imagen_toalla from "../assets/img/imagen_toalla.png";
import imagen_turin from "../assets/img/imagen_turin.png";

export const product = [
  {
    id: 1,
    name: "Turin",
    descripcion: " Tela ideal para camisetas, disfraces, forros, entre otros.",
    precio: 5000,
    imagen: imagen_turin,
  },
  {
    id: 2,
    name: "Doble punto colores",
    descripcion:
      "Una tela liviana perfecta para confeccionar prendas como pijamas.",
    precio: 9000,
    imagen: imagen_doble_punto,
  },
  {
    id: 3,
    name: "Pacific",
    descripcion: " trajes de ciclismo, vestidos de baño, entre otros.",
    precio: 16500,
    imagen: imagen_pacific,
  },
  {
    id: 4,
    name: "Antifluido",
    descripcion:
      " Tela ideal para la confección de pantalonetas, sudadera, entre otro.",
    precio: 7500,
    imagen: imagen_antifluido,
  },
  {
    id: 5,
    name: "Toalla Microfibra",
    descripcion:
      "Tela ideal para la confección de toallas para limpiar carros, salidas de baño para bebés, entre otros.",
    precio: 12000,
    imagen: imagen_toalla,
  },
  {
    id: 6,
    name: "Dacron",
    descripcion: " Tela ideal para forro para almohadas y más",
    precio: 6500,
    imagen: imagen_dacron,
  },
];
