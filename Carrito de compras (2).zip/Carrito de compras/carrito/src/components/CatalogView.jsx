import { useEffect, useState } from "react";
import { getProducts } from "../services/productsService";
import { ProductCardView } from "./ProductCardView";

export const CatalogView = ({handler}) => {
  const [prorducts, setProducts] = useState([]);
  useEffect(() => {
    setProducts(getProducts());
  }, []);
  return (
    <>
      <div className="row">
        {prorducts.map((prod) => (
          <div className="col-4 my-2" key={prod.id}>
            <ProductCardView
            handler={handler}
              id={prod.id}
              name={prod.name}
              descripcion={prod.descripcion}
              precio={prod.precio}
              imagen={prod.imagen}
            />
          </div>
        ))}
      </div>
    </>
  );
};
