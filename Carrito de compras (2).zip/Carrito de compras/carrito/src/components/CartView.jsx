import { useState, useEffect } from "react";
import { calcularTotal } from "../services/productsService";

export const CartView = ({ handlerDelete, items }) => {
  const [Total, setTotal] = useState(0);
  useEffect(()=> {
    setTotal(calcularTotal(items));
    sessionStorage.setItem("cart", JSON.stringify(items));
    [items];
  });
  const onDeleteProduct = (id) => {
    console.log("producto eliminado");
    handlerDelete(id);
  };
  return (
    <>
      <h3>Carrito de compra</h3>
      <table className="table table-hover table-striped">
        {/* Columna */}
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Cantidad</th>
            <th>Total</th>
            <th>Eliminar</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.product.id}>
              <td>{item.product.name}</td>
              <td>{item.product.precio}</td>
              <td>{item.quantity}</td>
              <td>{item.quantity * item.product.precio}</td>
              <td>
                <button
                  className="btn btn-danger"
                  onClick={() => onDeleteProduct(item.product.id)}
                >
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <td colSpan="3" className="text-end fw-bold">
              total
            </td>
            <td colSpan="2" className="text-start fw-bold">
              {Total}
            </td>
          </tr>
        </tfoot>
      </table>
    </>
  );
};
