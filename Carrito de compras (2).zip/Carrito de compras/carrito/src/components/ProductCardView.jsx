import React from "react";

export const ProductCardView = ({
  handler,
  id,
  name,
  descripcion,
  precio,
  imagen,
}) => {
  const onAddProduct = (products) => {
    // console.log(products);
    handler(products);
  };
  return (
    <>
      <div className="card">
        <img src={imagen} className="card-img.top" alt="producto" />
        <div className="card-body">
          <h5 className="card-title">{name}</h5>
          <p className="card-text">{descripcion} </p>
          <p className="card-text">$ {precio}</p>
          <button
            className="btn btn-primary"
            onClick={() => onAddProduct({ id, name, descripcion, precio })}
          >
            Agregar
          </button>
        </div>
      </div>
    </>
  );
};
